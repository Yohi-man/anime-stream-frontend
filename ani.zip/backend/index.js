const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

const animeList = [
  { id: 1, title: 'Naruto', description: 'A young ninja strives to be the strongest.' },
  { id: 2, title: 'Attack on Titan', description: 'Humanity fights against giant titans.' },
  { id: 3, title: 'One Piece', description: 'A pirate’s journey to find the ultimate treasure.' },
];

// Routes
app.get('/', (req, res) => {
  res.send('Welcome to AnimeStream API');
});

app.get('/anime', (req, res) => {
  res.json(animeList);
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));