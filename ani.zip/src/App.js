import React from 'react';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <header className="bg-gray-800 p-4">
        <h1 className="text-center text-3xl font-bold">Anime Streaming</h1>
      </header>
      <main className="p-8">
        <p className="text-center text-xl">Welcome to your anime streaming platform!</p>
      </main>
      <footer className="bg-gray-800 p-4 text-center">
        <p>&copy; 2025 AnimeStream. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;