import React from 'react';

function About() {
  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold text-blue-500">About AnimeStream</h1>
      <p className="mt-2 text-white">AnimeStream is the ultimate platform for anime lovers to enjoy their favorite shows seamlessly.</p>
    </div>
  );
}

export default About;