import React from 'react';

function Watch() {
  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold text-blue-500">Watch Anime</h1>
      <p className="mt-2 text-white">Start streaming high-quality anime now!</p>
    </div>
  );
}

export default Watch;