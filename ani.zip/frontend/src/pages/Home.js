import React from 'react';

function Home() {
  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold text-blue-500">Welcome to AnimeStream</h1>
      <p className="mt-2 text-white">Stream your favorite anime with the best UI and smooth experience.</p>
    </div>
  );
}

export default Home;